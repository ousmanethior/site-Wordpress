<?php 
if ( function_exists('mse_map')) { 
$of_categories = array();  
$of_categories_obj = get_categories('hide_empty=0');
foreach ($of_categories_obj as $of_cat) {
    $of_categories[$of_cat->cat_name] = $of_cat->cat_ID;} 

$ads = array();
$get_e3lanat = get_posts('post_type=ads&posts_per_page=-1');
foreach ($get_e3lanat as $ad ) {
    $ads[$ad->post_title] = $ad->ID;
}

$images = get_template_directory_uri().'/framework/shortcodes/images';

$ani = array(
    'bounce'  => 'bounce',
'flash' => 'flash',
'pulse' => 'pulse',
'rubberBand'  => 'rubberBand',
'shake' => 'shake',
'swing' => 'swing',
'tada'  => 'tada',
'wobble'  => 'wobble',
'bounceIn'  => 'bounceIn',
'bounceInDown'  => 'bounceInDown',
'bounceInLeft'  => 'bounceInLeft',
'bounceInRight' => 'bounceInRight',
'bounceInUp'  => 'bounceInUp',
'fadeIn'  => 'fadeIn',
'fadeInDown'  => 'fadeInDown',
'fadeInDownBig' => 'fadeInDownBig',
'fadeInLeft'  => 'fadeInLeft',
'fadeInLeftBig' => 'fadeInLeftBig',
'fadeInRight' => 'fadeInRight',
'fadeInRightBig'  => 'fadeInRightBig',
'fadeInUp'  => 'fadeInUp',
'fadeInUpBig' => 'fadeInUpBig',
'flip'  => 'flip',
'flipInX' => 'flipInX',
'flipInY' => 'flipInY',
'lightSpeedIn'  => 'lightSpeedIn',
'rotateIn'  => 'rotateIn',
'rotateInDownLeft'  => 'rotateInDownLeft',
'rotateInDownRight' => 'rotateInDownRight',
'rotateInUpLeft'  => 'rotateInUpLeft',
'rotateInUpRight' => 'rotateInUpRight',
'slideInDown' => 'slideInDown',
'slideInLeft' => 'slideInLeft',
'slideInRight'  => 'slideInRight',
'hinge' => 'hinge',
'rollIn'  => 'rollIn',  
);



$ani_out = array(
   'bounceOut'  => 'bounceOut',
   'bounceOutDown'  => 'bounceOutDown',
   'bounceOutLeft'  => 'bounceOutLeft',
   'bounceOutRight' => 'bounceOutRight',
   'bounceOutUp'  => 'bounceOutUp',
   'fadeOut'  => 'fadeOut',
   'fadeOutDown'  => 'fadeOutDown',
   'fadeOutDownBig' => 'fadeOutDownBig',
   'fadeOutLeft'  => 'fadeOutLeft',
   'fadeOutLeftBig' => 'fadeOutLeftBig',
   'fadeOutRight' => 'fadeOutRight',
   'fadeOutRightBig'  => 'fadeOutRightBig',
   'fadeOutUp'  => 'fadeOutUp',
   'fadeOutUpBig' => 'fadeOutUpBig',
   'flip'  => 'flip',
   'flipOutX' => 'flipOutX',
   'flipOutY' => 'flipOutY',
   'lightSpeedOut'  => 'lightSpeedOut',
   'rotateOut'  => 'rotateOut',
   'rotateOutDownLeft'  => 'rotateOutDownLeft',
   'rotateOutDownRight' => 'rotateOutDownRight',
   'rotateOutUpLeft'  => 'rotateOutUpLeft',
   'rotateOutUpRight' => 'rotateOutUpRight',
   'slideOutDown' => 'slideOutDown',
   'slideOutLeft' => 'slideOutLeft',
   'slideOutRight'  => 'slideOutRight',
   'rollOut'  => 'rollOut',  
);
$vc_formats = array(
       __('Gallery') => 'gallery',
       __('Audio') => 'audio',
       __('Video') => 'video',
       __('Chat') => 'chat',
        );
    
mse_map( array(
    "name" => __("News Box", "framework"),
    "base" => "news_box",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_newsbox',
    "description" => __("insert news boxes.", 'theme'),
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Style", 'theme'),
         "param_name" => "style",
   "admin_label" => true,
         "description" => __("select from newsbox styles.", 'theme'),
         "value" => array(
      'Default' => '1',
      'Style 2' => '2',
      'Style 3' => '3',
      'Style 4' => '4',
      'Two Columns' => 'two_cols',
      ),
      ),
      
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Last", 'theme'),
         "param_name" => "last",
        "dependency" => Array('element' => "style", 'value' => array('two_cols')),
         "value" => array(
        __("No", 'theme') => '',
        __("Yes", 'theme') => 'yes',
        ),
      ),  
    array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Title", 'theme'),
         "param_name" => "title",
         "value" => '',
         "description" => __("if you select display category or tag leave this blank and it will be the category/tag name.", 'theme')
      ),
    array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Link", 'theme'),
         "param_name" => "link",
         "value" => '',
         "description" => __("if you select display category or tag leave this blank and it will be the category/tag Link.", 'theme')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Link Target", 'theme'),
         "param_name" => "link_target",
   "admin_label" => true,
         "value" => array(
      __('Open in same window', 'theme') => '' ,
      __('Open in new window', 'theme') => '_blank',
      ),
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Display", 'theme'),
         "param_name" => "display",
   "admin_label" => true,
         "value" => array(
      __('Latest Posts', 'theme') => '' ,
      __('Category', 'theme') => 'category',
      __('Tag', 'theme') => 'tag'
      ),
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Category", 'theme'),
         "param_name" => "category",
        "dependency" => Array('element' => "display", 'value' => array('category')),
   "admin_label" => true,
         "value" => array( "Select a Category" => '' ) + $of_categories,
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Tag ID", 'theme'),
         "param_name" => "tag",
        "dependency" => Array('element' => "display", 'value' => array('tag')),
         "admin_label" => true,
         "value" => '',
      ),

      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Exclude Categories", 'theme'),
         "param_name" => "exclude_categories",
         "description" => __('Saperate each category id with comma ex: 1,5,7', 'theme')
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Number of posts", 'theme'),
         "param_name" => "count",
         "description" => __('this count start after the recent post it mean if you set this as 10 the newsbox will show 11 posts the top post then the 10', 'theme')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("order by", 'theme'),
         "param_name" => "orderby",
         "value" => array(
        __("Recent", 'theme') => '',
        __("Popular", 'theme') => 'popular',
        __("Random", 'theme') => 'random',
        ),
      ),      
        array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Sort by", 'theme'),
         "param_name" => "sort",
         "value" => array(
        __("DESC", 'theme') => '',
        __("ASC", 'theme') => 'ASC',
        ),
      ),      
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Show more Button"),
         "param_name" => "show_more",
         "description" => __('Disable show more button as tabs on bottom of each news box', 'theme'),
        "value" => Array(__("Show/hide", "js_composer") => 'on')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("On click"),
         "param_name" => "show_more_type",
         "value" => array(
      __('More posts with Ajax', 'theme') => '',
      __('Category/tag page', 'theme') => 'link' ,
    ),
      ),

       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Custom post type", 'framework'),
   "admin_label" => true,
         "param_name" => "post_type",
         "description" => __('Advanced: you can use this option to get posts from custom post types, if you set this to anything the category and tags options not working', 'framework')
      ),
       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Class", 'framework'),
          "admin_label" => true,
         "param_name" => "class",
         "description" => __('Extra CSS Class', 'framework')
      ),
// colors
       array(
         "type" => "title",
         "class" => "",
         "value" => __("Header Colors", 'framework'),
         "param_name" => "hc_title",
        ),

       array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Header Background Color", 'framework'),
         "param_name" => "header_background",
      ),
       array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Header Text Color", 'framework'),
         "param_name" => "header_text_color",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Hider dots pattern"),
         "param_name" => "hide_dots",
         "value" => array(
      __('No', 'theme') => '',
      __('Yes', 'theme') => 'yes' ,
    ),
      ),
//colors end 
   )
));

mse_map( array(
    "name" => __("News List", "framework"),
    "base" => "news_list",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_newslist',
    "description" => __("insert news lists.", 'theme'),
    "params" => array(
    array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Title", 'theme'),
         "param_name" => "title",
         "value" => '',
         "description" => __("if you select display category or tag leave this blank and it will be the category/tag name.", 'theme')
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Image Size", 'theme'),
         "param_name" => "image_size",
         "value" => array(
      __('Medium', 'theme') => '' ,
      __('Big', 'theme') => 'big',
      ),
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Display", 'theme'),
         "param_name" => "display",
   "admin_label" => true,
         "value" => array(
      __('Latest Posts', 'theme') => '' ,
      __('Category', 'theme') => 'category',
      __('Tag', 'theme') => 'tag'
      ),
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Category", 'theme'),
         "param_name" => "category",
        "dependency" => Array('element' => "display", 'value' => array('category')),
   "admin_label" => true,
         "value" => array( "Select a Category" => '' ) + $of_categories,
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Tag ID", 'theme'),
         "param_name" => "tag",
        "dependency" => Array('element' => "display", 'value' => array('tag')),
   "admin_label" => true,
         "value" => '',
      ),

      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Format", 'theme'),
         "param_name" => "format",
   "admin_label" => true,
  "description" => __('display posts by format, leave blank for all post formats spaerated by comma for multiple formats', 'theme'),
         "value" => '',
      ),

      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Exclude Categories", 'theme'),
         "param_name" => "exclude_categories",
         "description" => __('Saperate each category id with comma ex: 1,5,7', 'theme')
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Number of posts", 'theme'),
   "admin_label" => true,
         "param_name" => "count",
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Excerpt Length", 'theme'),
         "param_name" => "excerpt_length",
         "description" => __('characters length default is 150', 'theme')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("order by", 'theme'),
         "param_name" => "orderby",
         "value" => array(
        __("Recent", 'theme') => '',
        __("Popular", 'theme') => 'popular',
        __("Random", 'theme') => 'random',
        ),
      ),      
        array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Sort by", 'theme'),
         "param_name" => "sort",
         "value" => array(
        __("DESC", 'theme') => '',
        __("ASC", 'theme') => 'ASC',
        ),
      ),      
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Show more Button"),
         "param_name" => "show_more",
         "description" => __('Disable show more button as tabs on bottom of each news box', 'theme'),
        "value" => Array(__("Show/hide", "js_composer") => 'on')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("On click"),
         "param_name" => "show_more_type",
         "value" => array(
      __('More posts with Ajax', 'theme') => '',
      __('Category/tag page', 'theme') => 'link' ,
    ),
      ),
       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Custom post type", 'framework'),
   "admin_label" => true,
         "param_name" => "post_type",
         "description" => __('Advanced: you can use this option to get posts from custom post types, if you set this to anything the category and tags options not working', 'framework')
      ),
       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Class", 'framework'),
          "admin_label" => true,
         "param_name" => "class",
         "description" => __('Extra CSS Class', 'framework')
      ),
// colors
       array(
         "type" => "title",
         "class" => "",
         "value" => __("Header Colors", 'framework'),
         "param_name" => "hc_title",
        ),
       
       array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Header Background Color", 'framework'),
         "param_name" => "header_background",
      ),

       array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Header Text Color", 'framework'),
         "param_name" => "header_text_color",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Hider dots pattern"),
         "param_name" => "hide_dots",
         "value" => array(
      __('No', 'theme') => '',
      __('Yes', 'theme') => 'yes' ,
    ),
      ),
//colors end 
   )
));

mse_map( array(
    "name" => __("Scrolling box", "framework"),
    "base" => "scrolling_box",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_scrolling_box',
    "description" => __("insert posts carousel.", 'theme'),
    "params" => array(
    array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Title", 'theme'),
         "param_name" => "title",
         "value" => '',
         "description" => __("if you select display category or tag leave this blank and it will be the category/tag name.", 'theme')
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Display", 'theme'),
         "param_name" => "display",
   "admin_label" => true,
         "value" => array(
      __('Latest Posts', 'theme') => '' ,
      __('Category', 'theme') => 'category',
      __('Tag', 'theme') => 'tag'
      ),
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Category", 'theme'),
         "param_name" => "category",
        "dependency" => Array('element' => "display", 'value' => array('category')),
   "admin_label" => true,
         "value" => array( "Select a Category" => '' ) + $of_categories,
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Tag ID", 'theme'),
         "param_name" => "tag",
        "dependency" => Array('element' => "display", 'value' => array('tag')),
   "admin_label" => true,
         "value" => '',
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Format", 'theme'),
         "param_name" => "format",
  "description" => __('display posts by format, leave blank for all post formats spaerated by comma for multiple formats', 'theme'),
   "admin_label" => true,
         "value" => '',
      ),

      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Exclude Categories", 'theme'),
         "param_name" => "exclude_categories",
         "description" => __('Saperate each category id with comma ex: 1,5,7', 'theme')
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Number of posts", 'theme'),
         "param_name" => "count",
   "admin_label" => true,
  "description" => __('-1 for all posts', 'theme'),
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Items", 'theme'),
         "param_name" => "items",
   "admin_label" => true,
  "description" => __('items displayed at a time depend on width default is 3', 'theme'),
         "value" => '',
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Rows", 'theme'),
         "param_name" => "rows",
   "admin_label" => true,
  "description" => __('with this option you can display the scrolling box in multi rows, the default is 1', 'theme'),
         "value" => '',
      ),      
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Excerpt Length", 'theme'),
         "param_name" => "excerpt_length",
         "description" => __('characters length default is 0', 'theme')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("order by", 'theme'),
         "param_name" => "orderby",
         "value" => array(
        __("Recent", 'theme') => '',
        __("Popular", 'theme') => 'popular',
        __("Random", 'theme') => 'random',
        ),
      ),      
        array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Sort by", 'theme'),
         "param_name" => "sort",
         "value" => array(
        __("DESC", 'theme') => '',
        __("ASC", 'theme') => 'ASC',
        ),
      ),      
       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Custom post type", 'framework'),
   "admin_label" => true,
         "param_name" => "post_type",
         "description" => __('Advanced: you can use this option to get posts from custom post types, if you set this to anything the category and tags options not working', 'framework')
      ),
       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Class", 'framework'),
          "admin_label" => true,
         "param_name" => "class",
         "description" => __('Extra CSS Class', 'framework')
      ),
// colors
       array(
         "type" => "title",
         "class" => "",
         "value" => __("Header Colors", 'framework'),
         "param_name" => "hc_title",
        ),
       array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Header Background Color", 'framework'),
         "param_name" => "header_background",
      ),

       array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Header Text Color", 'framework'),
         "param_name" => "header_text_color",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Hider dots pattern"),
         "param_name" => "hide_dots",
         "value" => array(
      __('No', 'theme') => '',
      __('Yes', 'theme') => 'yes' ,
    ),
      ),
//colors end        

   )
));


mse_map( array(
    "name" => __("Feature Slider", "framework"),
    "base" => "feature_slider",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_feature_slider',
    "description" => __("insert Feature Slider.", 'theme'),
    "params" => array(

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Style", 'framework'),
         "param_name" => "style",
         'admin_label' => 'true',
         "value" => array(
          __('Old', 'theme') => 'old',
          __('New', 'theme') => 'new',
          
         ), 
       
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Full width slider ", 'framework'),
         "param_name" => "full_width",
         "value" => array(
          'No' => 'no',
          'Yes' => 'yes',
         ), 
         "dependency" => Array('element' => "style", 'value' => array('new')),
         
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("No spaces in the slider", 'framework'),
         "param_name" => "no_spaces",
         "value" => array(
    'No' => 'no',
    'Yes' => 'yes',
   ), 
         "dependency" => Array('element' => "style", 'value' => array('new')),

      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Display", 'theme'),
         "param_name" => "display",
         "value" => array(
      __('Latest Posts', 'theme') => '' ,
      __('Category', 'theme') => 'category',
      __('Tag', 'theme') => 'tag'
      ),
      ),


      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Category", 'theme'),
         "param_name" => "category",
        "dependency" => Array('element' => "display", 'value' => array('category')),
         "value" => array( "Select a Category" => '' ) + $of_categories,
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Tag ID", 'theme'),
         "param_name" => "tag",
        "dependency" => Array('element' => "display", 'value' => array('tag')),
         "value" => '',
      ),

      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Exclude Categories", 'theme'),
         "param_name" => "exclude_categories",
         "description" => __('Saperate each category id with comma ex: 1,5,7', 'theme')
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Number of posts", 'theme'),
         "param_name" => "count",
  "description" => __('-1 for all posts', 'theme'),
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("order by", 'theme'),
         "param_name" => "orderby",
         "value" => array(
        __("Recent", 'theme') => '',
        __("Popular", 'theme') => 'popular',
        __("Random", 'theme') => 'random',
        ),
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Caption", 'theme'),
         "param_name" => "caption",
         "value" => array(
        __("ON", 'theme') => 'on',
        __("OFF", 'theme') => 'off',
        ),
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Caption Style", 'theme'),
         "param_name" => "caption_style",
         "value" => array(
        __("Default", 'theme') => '',
        __("Alt", 'theme') => 2,
        ),
      ),
            
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Caption Length", 'theme'),
         "param_name" => "caption_length",
         "description" => __('characters length default is 110', 'theme')
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Post Title font size", 'theme'),
         "param_name" => "caption_title_size",
         "description" => __('in pixels ex: 20px', 'theme')
      ),
          
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Caption text font size", 'theme'),
         "param_name" => "caption_text_size",
         "description" => __('in pixels ex: 14px', 'theme')
      ),
          
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Navigation", 'theme'),
         "param_name" => "nav",
         "value" => array(
        __("Bullets", 'theme') => 'bullets',
        __("Thumbs", 'theme') => 'thumbs',
        __("Numbers", 'theme') => 'numbers',
      ),
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Slider Thumbnails event", 'theme'),
         "description" => __('Do what to see the current slide', 'theme'),
         "param_name" => "thumbs_event",
        "dependency" => Array('element' => "nav", 'value' => array('thumbs')),
         "value" => array(
            __("Click", 'theme') => 'click',
            __("Mouse over", 'theme') => 'mouseenter'
      ),
      ),


      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Arrows", 'theme'),
         "param_name" => "arrows",
         "value" => array(
        __("OFF", 'theme') => 'off',
        __("ON", 'theme') => 'on',
        ),
      ),  
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Number of thumbnails", 'theme'),
         "param_name" => "items",
         "description" => __('default is 6', 'theme')
      ),

// new style animation
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Animation", 'framework'),
         "param_name" => "animation_new",
         "dependency" => Array('element' => "style", 'value' => array('new')),
         "description" => __('post excerpt length in characters leave empty for default values', 'framework'),
         "value" => array(
      'Fade' => 'fade',
      'Slide' => 'slide',
      'Flip' => 'flip',
      'Custom Animation' => 'custom',
      ),
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Animation Out", 'framework'),
         "param_name" => "animation_out",
         "dependency" => Array('element' => "animation_new", 'value' => array('custom')),
         "description" => __('slider item out animation', 'framework'),
         "value" => $ani_out
      ),
      
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Animation In", 'framework'),
         "param_name" => "animation_in",
         "dependency" => Array('element' => "animation_new", 'value' => array('custom')),
         "description" => __('slider item in animation', 'framework'),
         "value" => $ani
      ),


      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Auto Play", 'framework'),
         "param_name" => "autoplay",
         "value" => array(
    'Yes' => 'yes',
    'No' => 'no'
   )
      ),
//end new style animation
        array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Animation", 'theme'),
         "param_name" => "animation",
         "value" => array(
        __("crossfade", 'theme') => 'crossfade',
        __("scroll", 'theme') => 'scroll',
        __("directscroll", 'theme') => 'directscroll',
        __("fade", 'theme') => 'fade',
        __("cover", 'theme') => 'cover',
        __("cover-fade", 'theme') => 'cover-fade',
        __("uncover", 'theme') => 'uncover',
        __("uncover-fade", 'theme') => 'uncover-fade',
      ),
                 "dependency" => Array('element' => "style", 'value' => array('')),

      ),      
        array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Easing", 'theme'),
         "param_name" => "easing",
         "value" => array(
  __('easeInOutCubic', 'theme') => 'easeInOutCubic',
  __('jswing', 'theme') => 'jswing',
  __('def', 'theme') => 'def',
  __('easeInQuad', 'theme') => 'easeInQuad',
  __('easeOutQuad', 'theme') => 'easeOutQuad',
  __('easeInOutQuad', 'theme') => 'easeInOutQuad',
  __('easeInCubic', 'theme') => 'easeInCubic',
  __('easeOutCubic', 'theme') => 'easeOutCubic',
  __('easeInQuart', 'theme') => 'easeInQuart',
  __('easeOutQuart', 'theme') => 'easeOutQuart',
  __('easeInOutQuart', 'theme') => 'easeInOutQuart',
  __('easeInQuint', 'theme') => 'easeInQuint',
  __('easeOutQuint', 'theme') => 'easeOutQuint',
  __('easeInOutQuint', 'theme') => 'easeInOutQuint',
  __('easeInSine', 'theme') => 'easeInSine',
  __('easeOutSine', 'theme') => 'easeOutSine',
  __('easeInOutSine', 'theme') => 'easeInOutSine',
  __('easeInExpo', 'theme') => 'easeInExpo',
  __('easeOutExpo', 'theme') => 'easeOutExpo',
  __('easeInOutExpo', 'theme') => 'easeInOutExpo',
  __('easeInCirc', 'theme') => 'easeInCirc',
  __('easeOutCirc', 'theme') => 'easeOutCirc',
  __('easeInOutCirc', 'theme') => 'easeInOutCirc',
  __('easeInElastic', 'theme') => 'easeInElastic',
  __('easeOutElastic', 'theme') => 'easeOutElastic',
  __('easeInOutElastic', 'theme') => 'easeInOutElastic',
  __('easeInBack', 'theme') => 'easeInBack',
  __('easeOutBack', 'theme') => 'easeOutBack',
  __('easeInOutBack', 'theme') => 'easeInOutBack',
  __('easeInBounce', 'theme') => 'easeInBounce',
  __('easeOutBounce', 'theme') => 'easeOutBounce',
  __('easeInOutBounce', 'theme') => 'easeInOutBounce',
    ),
                 "dependency" => Array('element' => "style", 'value' => array('')),

      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Animation Speed", 'theme'),
         "param_name" => "speed",
                 "dependency" => Array('element' => "style", 'value' => array('')),
           "description" => __('in ms, default is 600', 'theme')
      ),  

      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Timeout", 'theme'),
         "param_name" => "timeout",
         "description" => __('the time between each slide in ms, default 4000 = 4 seconds', 'theme')
      ),
      
       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Custom post type", 'framework'),
   "admin_label" => true,
         "param_name" => "post_type",
         "description" => __('Advanced: you can use this option to get posts from custom post types, if you set this to anything the category and tags options not working', 'framework')
      ),
       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Class", 'framework'),
          "admin_label" => true,
         "param_name" => "class",
         "description" => __('Extra CSS Class', 'framework')
      ),      
   )
));

mse_map( array(
    "name" => __("Blog Posts", "framework"),
    "base" => "blog_posts",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_blog_posts',
    "description" => __("insert blog posts.", 'theme'),
    "params" => array(

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Style", 'theme'),
         "param_name" => "style",
         "value" => array(
      __('Medium Thumbnails', 'theme') => 'm1' ,
      __('Medium Thumbnails2', 'theme') => 'm2',
      __('Large Thumbnails', 'theme') => 'l',
      __('Grid', 'theme') => 'g',
      ),
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Grid columns", 'theme'),
         "param_name" => "cols",
         "value" => array(
        __("Two columns", 'theme') => 2,
        __("Three columns", 'theme') => 3,
        __("Four columns", 'theme') => 4,
        ),
        "dependency" => Array('element' => "style", 'value' => array('g')),
      ),
      

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Share Icons", 'theme'),
         "param_name" => "share",
         "value" => array(
        __("ON", 'theme') => 'on',
        __("OFF", 'theme') => 'off',
        ),
      ),
      
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Display", 'theme'),
         "param_name" => "display",
         "value" => array(
      __('Latest Posts', 'theme') => '' ,
      __('Category', 'theme') => 'category',
      __('Tag', 'theme') => 'tag'
      ),
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Category", 'theme'),
         "param_name" => "category",
        "dependency" => Array('element' => "display", 'value' => array('category')),
         "value" => array( "Select a Category" => '' ) + $of_categories,
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Tag ID", 'theme'),
         "param_name" => "tag",
        "dependency" => Array('element' => "display", 'value' => array('tag')),
         "value" => '',
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Format", 'theme'),
         "param_name" => "format",
  "description" => __('display posts by format, leave blank for all post formats spaerated by comma for multiple formats', 'theme'),
         "value" => '',
      ),

      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Number of posts", 'theme'),
         "param_name" => "count",
  "description" => __('-1 for all posts', 'theme'),
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Excerpt Length", 'theme'),
         "param_name" => "excerpt_length",
         "description" => __('characters length', 'theme')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("order by", 'theme'),
         "param_name" => "orderby",
         "value" => array(
        __("Recent", 'theme') => '',
        __("Popular", 'theme') => 'popular',
        __("Random", 'theme') => 'random',
        ),
      ),      
        array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Sort by", 'theme'),
         "param_name" => "sort",
         "value" => array(
        __("DESC", 'theme') => '',
        __("ASC", 'theme') => 'ASC',
        ),
      ),      

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Pagination", 'theme'),
         "param_name" => "pagination",
         "value" => array(
        __("ON", 'theme') => 'on',
        __("OFF", 'theme') => 'off',
        ),
      ),
      
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Pagination type", 'theme'),
         "param_name" => "pagination_type",
        "dependency" => Array('element' => "pagination", 'value' => array('on')),
         "description" => __('caution: dont use ajax pagination if you order post by', 'theme'),
         "value" => array(
      __('Default') => '',  
      __('Ajax') => 'ajax',  
    ),
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Post count on load", 'theme'),
         "param_name" => "load_more_count",
        "dependency" => Array('element' => "pagination", 'value' => array('on')),
         "value" => '',
         "description" => __('the count of posts on load if you set the pagination type to ajax default is 3', 'theme')
      ),

// ads 
       array(
         "type" => "title",
         "class" => "",
         "value" => __("Ads", 'framework'),
         "param_name" => "hc_title",
        ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Select Ad:", 'theme'),
         "param_name" => "ad_id",
         "value" => array('')+$ads,
      ),
      
  array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Display after x posts", 'theme'),
         "param_name" => "ad_count",
         "value" => 3,
         "description" => __('the number of posts to display ads after it. default is 3', 'theme')
      ),

    array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Repeat ad", 'theme'),
         "param_name" => "ad_repeat",
         "description" => __('display the ad again after x posts', 'theme'),
         "value" => Array(__("Yes", "framework") => 'yes')
      ),
   
             
   )
));

mse_map( array(
    "name" => __("News in pictures", "framework"),
    "base" => "news_in_pics",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_news_pics',
    "description" => __("insert news in pictures.", 'theme'),
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Style", 'theme'),
         "param_name" => "style",
         "description" => __("select from newsbox styles.", 'theme'),
         "value" => array(
      'Grid' => '1',
      'Grid with feature post' => '2',
      ),
      ),
      
  array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Title", 'theme'),
         "param_name" => "title",
         "value" => '',
         "description" => __("if you select display category or tag leave this blank and it will be the category/tag name.", 'theme')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Display", 'theme'),
         "param_name" => "display",
   "admin_label" => true,
         "value" => array(
      __('Latest Posts', 'theme') => '' ,
      __('Category', 'theme') => 'category',
      __('Tag', 'theme') => 'tag'
      ),
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Category", 'theme'),
         "param_name" => "category",
        "dependency" => Array('element' => "display", 'value' => array('category')),
   "admin_label" => true,
         "value" => array( "Select a Category" => '' ) + $of_categories,
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Tag ID", 'theme'),
         "param_name" => "tag",
        "dependency" => Array('element' => "display", 'value' => array('tag')),
   "admin_label" => true,
         "value" => '',
      ),

      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Exclude Categories", 'theme'),
         "param_name" => "exclude_categories",
         "description" => __('Saperate each category id with comma ex: 1,5,7', 'theme')
      ),
      array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Number of posts", 'theme'),
         "param_name" => "count",
   "admin_label" => true,
         "description" => __('this count start after the recent post it mean if you set this as 10 the newsbox will show 11 posts the top post then the 10', 'theme')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("order by", 'theme'),
         "param_name" => "orderby",
         "value" => array(
        __("Recent", 'theme') => '',
        __("Popular", 'theme') => 'popular',
        __("Random", 'theme') => 'random',
        ),
      ),      
        array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Sort by", 'theme'),
         "param_name" => "sort",
         "value" => array(
        __("DESC", 'theme') => '',
        __("ASC", 'theme') => 'ASC',
        ),
      ),      
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Show more Button"),
         "param_name" => "show_more",
         "description" => __('Disable show more button as tabs on bottom of each news box', 'theme'),
        "value" => Array(__("Show/hide", "js_composer") => 'on')
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("On click"),
         "param_name" => "show_more_type",
         "value" => array(
      __('More posts with Ajax', 'theme') => '',
      __('Category/tag page', 'theme') => 'link' ,
    ),
      ),

       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Custom post type", 'framework'),
   "admin_label" => true,
         "param_name" => "post_type",
         "description" => __('Advanced: you can use this option to get posts from custom post types, if you set this to anything the category and tags options not working', 'framework')
      ),
       array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Class", 'framework'),
          "admin_label" => true,
         "param_name" => "class",
         "description" => __('Extra CSS Class', 'framework')
      ),
// colors
       array(
         "type" => "title",
         "class" => "",
         "value" => __("Header Colors", 'framework'),
         "param_name" => "hc_title",
        ),
       
       array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Header Background Color", 'framework'),
         "param_name" => "header_background",
      ),

       array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Header Text Color", 'framework'),
         "param_name" => "header_text_color",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Hider dots pattern"),
         "param_name" => "hide_dots",
         "value" => array(
      __('No', 'theme') => '',
      __('Yes', 'theme') => 'yes' ,
    ),
      ),
//colors end        
   )
));

mse_map( array(
    "name" => __("Portfolio", "framework"),
    "base" => "portfolio",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_portfolio',
    "description" => __("insert portfolio items.", 'theme'),
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Columns", 'theme'),
         "param_name" => "columns",
         "description" => __("set the number of columns.", 'theme'),
         "value" => array(
      __('One columns', 'theme') => 'one',
      __('Two columns', 'theme') => 'two',
      __('Three columns', 'theme') => 'three',
      __('Four columns', 'theme') => 'four',
      ),
      ),
      
  array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Items per page", 'theme'),
         "param_name" => "count",
         "value" => '',
         "description" => __("By default its: 12.", 'theme')
      ),
 
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Navigation", 'theme'),
         "param_name" => "nav",
         "description" => __("filter, pagination, both or none.", 'theme'),
         "value" => array(
      __('Filter', 'theme') => 'filter',
      __('Pagination', 'theme') => 'pagination',
      __('Both', 'theme') => 'both',
      __('None', 'theme') => 'none',
      ),
      ), 
   )
));

/** Ad **/
mse_map( array(
    "name" => __("Ad", "framework"),
    "base" => "ad",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_ad',
    "description" => __("insert ad.", 'theme'),
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Select Ad:", 'theme'),
         "param_name" => "id",
         "value" => $ads,
      ),
      
   )
));

/** Rewiew **/
mse_map( array(
    "name" => __("Review", "framework"),
    "base" => "review",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_review',
    "description" => __("insert review.", 'theme'),
    "params" => array(
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Insert Post ID to get review from it:", 'theme'),
         "description" => __("leave empty for current post", 'theme'),
         "param_name" => "id",
         "value" => '',
      ),
      
   )
));

mse_map( array(
    "name" => __("Animator", "framework"),
    "base" => "animate",
  "category" => __('Goodnews'),
    "icon" => 'icon-mom_animate',
    "description" => __("elements Animation.", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    "as_parent" => array('except' => ''),
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Animation", 'theme'),
  "description" => __("tons of animations.", 'theme'),
         "param_name" => "animation",
         "value" => array(__('None') => '') + $ani,
      ),
      
            array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Duration", 'theme'),
  "description" => __("animation duration in seconds.", 'theme'),
         "param_name" => "duration",
      ),
            array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Delay", 'theme'),
  "description" => __("animated element delay in seconds.", 'theme'),
         "param_name" => "delay",
      ),
            array(
         "type" => "textfield",
         "class" => "",
         "heading" => __("Iteration Count", 'theme'),
  "description" => __("number of animation times -1 for non stop animation.", 'theme'),
         "param_name" => "iteration",
      ),        
   )
));


mse_map( array(
    "name" => __("Visibility", "framework"),
    "base" => "visibility",
  "category" => __('Goodnews'),
    "icon" => 'fa-eye',
    "description" => __("visibility options.", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    "as_parent" => array('except' => ''),
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Animation", 'theme'),
  "description" => __("tons of animations.", 'theme'),
         "param_name" => "visible_on",
         "value" => array(
        __('Desktop', 'theme') => 'desktop',
        __('Device (mobiles and tablets)', 'theme') => 'device',
        __('Tablet', 'theme') => 'tablet',
        __('Mobile', 'theme') => 'mobile',
        
      )
      ),
      
      
   )
));

/** map **/
mse_map( array(
    "name" => __("Map", "framework"),
    "base" => "google_map",
    "category" => __('Goodnews'),
    "icon" => 'fa-map-marker',
    "description" => __("", 'theme'),
    "content_element" => true,
    "params" => array(
          array(
             "type" => "text",
             "class" => "",
             "heading" => __("Width", 'theme'),
              "description" => __("in pixels or percent", 'theme'),
             "param_name" => "width",
          ),
          array(
             "type" => "text",
             "class" => "",
             "heading" => __("Height", 'theme'),
              "description" => __("in pixels or percent", 'theme'),
             "param_name" => "height",
          ),
          array(
             "type" => "text",
             "class" => "",
             "heading" => __("URL", 'theme'),
              "description" => __("map url here", 'theme'),
             "param_name" => "src",
          ),        
      
   )
));

/** Logain **/
mse_map( array(
    "name" => __("Login Form", "framework"),
    "base" => "login_form",
  "category" => __('Goodnews'),
    "icon" => 'fa-user',
    "description" => __("Add login form.", 'theme'),
    "content_element" => false,
    "params" => array(
          array(
             "type" => "text",
             "class" => "",
             "heading" => __("Register Page URL", 'theme'),
              "description" => __("", 'theme'),
             "param_name" => "register",
          ),
          array(
             "type" => "text",
             "class" => "",
             "heading" => __("Lost password Page URL", 'theme'),
              "description" => __("", 'theme'),
             "param_name" => "reset",
          ),      
      
   )
));

/** Register **/
mse_map( array(
    "name" => __("Register Form", "framework"),
    "base" => "register_form",
    "category" => __('Goodnews'),
    "icon" => 'fa-user',
    "description" => __("Add Register form.", 'theme'),
    "content_element" => false,
    "params" => array(
          array(
             "type" => "text",
             "class" => "",
             "heading" => __("Register Page URL", 'theme'),
              "description" => __("", 'theme'),
             "param_name" => "register",
          ),
          array(
             "type" => "text",
             "class" => "",
             "heading" => __("Lost password Page URL", 'theme'),
              "description" => __("", 'theme'),
             "param_name" => "reset",
          ),      
      
   )
));
/** Divider **/
mse_map( array(
    "name" => __("Divider", "framework"),
    "base" => "divide",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("Add Divider", 'theme'),
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Divider", 'theme'),
         "description" => __("4 styles, default margin bottom 25px", 'theme'),
         "param_name" => "style",
         "value" => array(
        __('Line', 'theme') => '',
        __('Dots', 'theme') => 'dots',
        __('Dashes', 'theme') => 'dashs',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "icon",
         "value" => array(
        __('None', 'theme') => '',
        __('Square', 'theme') => 'square',
        __('Circle', 'theme') => 'circle',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon Position", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "icon_position",
         "value" => array(
        __('Center', 'theme') => '',
        __('Left', 'theme') => 'left',
        __('Right', 'theme') => 'right',        
      )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Space above it", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "margin_top",
         "value" => "",     
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Space under it", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "margin_bottom",
         "value" => "",     
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Width", 'theme'),
         "description" => __("select divider width 'long, medium, short'", 'theme'),
         "param_name" => "width",
         "value" => array(
        __('Long', 'theme') => '',
        __('Medium', 'theme') => 'medium',
        __('Short', 'theme') => 'short',        
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Divider Color", 'theme'),
         "description" => __("custom color", 'theme'),
         "param_name" => "color",
         "value" => "",     
      ),
   )
));
/** dropcap **/
mse_map( array(
    "name" => __("Dropcap", "framework"),
    "base" => "dropcap",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Style", 'theme'),
         "description" => __("Dropcap Styles", 'theme'),
         "param_name" => "style",
         "value" => array(
        __('Normal', 'theme') => '',
        __('Square', 'theme') => 'square',
        __('Circle', 'theme') => 'circle',        
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Letter Color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "color",
         "value" => "",     
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "bgcolor",
         "value" => "",
         "required" => array('style', '', '!='),     
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Square Radius", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "sradius",
         "value" => "", 
         "dependency" => array('element' => "style", 'value' => array('square')), 
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "font",
         "value" => array(
        __('Default', 'theme') => '',
        __('Arial', 'theme') => 'arial',
        __('Georgia', 'theme') => 'georgia',
        __('Verdana, Geneva', 'theme') => 'verdana',
        __('Trebuchet', 'theme') => 'trebuchet',
        __('Times New Roman', 'theme') => 'times',
        __('Tahoma, Geneva', 'theme') => 'tahoma',
        __('Palatino', 'theme') => 'palatino',
        __('Helvetica', 'theme') => 'helvetica',
        __('Play', 'theme') => 'play',
      )
      ),
   )
));
/** Gap **/
mse_map( array(
    "name" => __("Gap", "framework"),
    "base" => "gap",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Height", 'theme'),
         "description" => __("Default is 40", 'theme'),
         "param_name" => "style",
         "value" => "",
      ),
      )
));
/** highlight **/
mse_map( array(
    "name" => __("highlight", "framework"),
    "base" => "highlight",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background", 'theme'),
         "description" => __("highlight background color", 'theme'),
         "param_name" => "bgcolor",
         "value" => "",     
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Text", 'theme'),
         "description" => __("highlight Text color", 'theme'),
         "param_name" => "txtcolor",
         "value" => "",     
      ),
    )
));

/** Quote **/
mse_map( array(
    "name" => __("Quote", "framework"),
    "base" => "quote",
    "category" => __('Goodnews'),
    "icon" => 'fa-quote-left',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font", 'theme'),
         "description" => __("quote content font", 'theme'),
         "param_name" => "font",
         "value" => array(
        __('Default', 'theme') => '',
        __('Arial', 'theme') => 'arial',
        __('Georgia', 'theme') => 'georgia',
        __('Verdana, Geneva', 'theme') => 'verdana',
        __('Trebuchet', 'theme') => 'trebuchet',
        __('Times New Roman', 'theme') => 'times',
        __('Tahoma, Geneva', 'theme') => 'tahoma',
        __('Palatino', 'theme') => 'palatino',
        __('Helvetica', 'theme') => 'helvetica',
        __('Play', 'theme') => 'play',
      )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Font Size", 'theme'),
         "description" => __("quote content font size eg. 18", 'theme'),
         "param_name" => "font_size",
         "value" => "",     
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font Style", 'theme'),
         "description" => __("normal or italic", 'theme'),
         "param_name" => "font_style",
         "value" => array(
        __('Normal', 'theme') => '',
        __('Italic', 'theme') => 'italic',        
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "bgcolor",
         "value" => "",     
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Text color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "color",
         "value" => "",     
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Highlight color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "bcolor",
         "value" => "",     
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Show Arrow", 'theme'),
         "description" => __("little arrow on highlight", 'theme'),
         "param_name" => "arrow",
         "value" => array(
        __('No', 'theme') => '',
        __('Yes', 'theme') => 'yes',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Alignment", 'theme'),
         "description" => __("it can be aligned with any content", 'theme'),
         "param_name" => "align",
         "value" => array(
        __('None', 'theme') => '',
        __('Right', 'theme') => 'right',        
        __('Left', 'theme') => 'left',        
      )
      ),
      
   )
));

/** Video **/
mse_map( array(
    "name" => __("Video", "framework"),
    "base" => "mom_video",
    "category" => __('Goodnews'),
    "icon" => 'fa-film',
    "description" => __("", 'theme'),
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Video Type", 'theme'),
         "description" => __("Vimeo or Youtube", 'theme'),
         "param_name" => "type",
         "value" => array(
        __('Youtube', 'theme') => '',
        __('Vimeo', 'theme') => 'vimeo',
      )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Video ID", 'theme'),
         "description" => __('video id is the bold text in this links : http://www.youtube.com/watch?v=XSo4JQnm8Bw, http://vimeo.com/7449107', 'theme'),
         "param_name" => "id",
         "value" => "",
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Video Width", 'theme'),
         "description" => __("in pixels", 'theme'),
         "param_name" => "width",
         "value" => "",
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Video Height", 'theme'),
         "description" => __("in pixels", 'theme'),
         "param_name" => "height",
         "value" => "",
      ),
     
 
   )
));
/** Tabs **/
mse_map( array(
    "name" => __("Tabs", "framework"),
    "base" => "tabs",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Align", 'theme'),
         "description" => __("Icon alignment", 'theme'),
         "param_name" => "align",
         "value" => array(
        __('Horizontal Tabsh', 'theme') => '1',
        __('Vertical Tabs', 'theme') => 'v1',        
        __('Vertical Tabs Big', 'theme') => 'v3',        
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Color", 'framework'),
         "param_name" => "icon_color",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Current Icon Color", 'framework'),
         "param_name" => "icon_current_color",
         "value" => "",
      ),
      array(
         "type" => "textarea",
         "class" => "",
         "heading" => __("Content", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "content",
         "default" => "
[tab title='Tab 1' ]tab content 1[/tab]
[tab title='Tab 2' ]tab content 2[/tab]
[tab title='Tab 3' ]tab content 3[/tab]
                    ",
      ),
    )
));

/** Accordion **/
mse_map( array(
    "name" => __("Accordions", "framework"),
    "base" => "accordions",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',

    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Type", 'theme'),
         "description" => __("accordion or toggle", 'theme'),
         "param_name" => "type",
         "value" => array(
        __('Accordion', 'theme') => '',
        __('Toggle', 'theme') => 'toggle',
       )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Handle", 'theme'),
         "description" => __("the icon on the left", 'theme'),
         "param_name" => "handle",
         "value" => array(
        __('Arrows', 'theme') => 'arrows',
        __('Numbers', 'theme') => 'numbers',
        __('Plus and Minus', 'theme') => 'pm',
        __('None', 'theme') => '',
       )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Space", 'theme'),
         "description" => __("small space between the accordions titles for nicer design", 'theme'),
         "param_name" => "space",
         "value" => array(
        __('No', 'theme') => '',
        __('Yes', 'theme') => 'yes',
        )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Video ID", 'theme'),
         "description" => __('video id is the bold text in this links : http://www.youtube.com/watch?v=XSo4JQnm8Bw, http://vimeo.com/7449107', 'theme'),
         "param_name" => "id",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "icon_color",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Current Icon Color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "icon_current_color",
         "value" => "",
      ),
      array(
         "type" => "textarea",
         "class" => "",
         "heading" => __("Content", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "content",
         "default" => "
[accordion title='accordion title 1']accordion content[/accordion]
[accordion title='accordion title 2']accordion content[/accordion]
                    ",
      ),
   )
));

/** Ad **/
mse_map( array(
    "name" => __("Ad", "framework"),
    "base" => "ad",
    "category" => __('Goodnews'),
    "icon" => 'fa-adn',
    "description" => __("", 'theme'),
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Select Ad", 'theme'),
         "description" => __("select the ad", 'theme'),
         "param_name" => "id",
         "value" => "",
      ),
      )
));

/** Box **/
mse_map( array(
    "name" => __("Box", "framework"),
    "base" => "box",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Type", 'theme'),
         "description" => __("select one or create your custom", 'theme'),
         "param_name" => "type",
         "value" => array(
        __('Default', 'theme') => '',
        __('Info', 'theme') => 'info',
        __('Note', 'theme') => 'note',
        __('Error', 'theme') => 'error',
        __('Tip', 'theme') => 'tip',
        __('Custom', 'theme') => 'custom',
        )
      ),
      array(
         "type" => "upload",
         "class" => "",
         "heading" => __("Background Image", 'theme'),
         "description" => __("Upload Background Image", 'theme'),
         "param_name" => "bgimg",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Color", 'theme'),
         "param_name" => "bg",
         "value" => "",
         "dependency" => array('element' => "type", 'value' => array('custom')),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Text Color", 'theme'),
         "param_name" => "color",
         "value" => "",
         "dependency" => array('element' => "type", 'value' => array('custom')),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Color", 'theme'),
         "param_name" => "border",
         "value" => "",
         "dependency" => array('element' => "type", 'value' => array('custom')),
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Radius", 'theme'),
         "description" => __("insert box border radius number eg. 10", 'theme'),
         "param_name" => "radius",
         "value" => "",
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Font Size", 'theme'),
         "description" => __("insert a font size as a number eg. 14", 'theme'),
         "param_name" => "fontsize",
         "value" => "",
      ),
      array(
         "type" => "textarea",
         "class" => "",
         "heading" => __("Content", 'theme'),
         "description" => __("Box Content", 'theme'),
         "param_name" => "content",
         "value" => "",
      ),
    )
));

/** Button **/
mse_map( array(
    "name" => __("Button", "framework"),
    "base" => "button",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Content", 'theme'),
         "description" => __("insert button text ex: Click Here", 'theme'),
         "param_name" => "content",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Color", 'theme'),
         "description" => __("Select one or make your own", 'theme'),
         "param_name" => "color",
         "value" => array(
        __('Default', 'theme') => '',
        __('Yellow', 'theme') => 'yellow',
        __('Orange', 'theme') => 'orange',
        __('Orange2', 'theme') => 'orange2',
        __('Red', 'theme') => 'red',
        __('Brown', 'theme') => 'brown',
        __('Pink', 'theme') => 'pink',
        __('Purple', 'theme') => 'purple',
        __('Dark Green', 'theme') => 'green2',
        __('Green', 'theme') => 'green',
        __('Blue', 'theme') => 'blue',
        __('Dark Blue', 'theme') => 'blue2',
        __('Dark Gray', 'theme') => 'gray2',
        __('Gray', 'theme') => 'gray',
        __('Custom', 'theme') => 'custom',
        )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "bgcolor",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Hover", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "hoverbg",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Text Color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "textcolor",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Text Hover", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "texthcolor",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Color", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "bordercolor",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Hover", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "hoverborder",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Size", 'theme'),
         "description" => __("select from medium or big", 'theme'),
         "param_name" => "size",
         "value" => array(
        __('Medium', 'theme') => '',
        __('Big', 'theme') => 'big',
        __('Bigger', 'theme') => 'bigger',
        )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Align", 'theme'),
         "description" => __("right,left and center", 'theme'),
         "param_name" => "align",
         "value" => array(
        __('Left', 'theme') => '',
        __('Right', 'theme') => 'right',
        __('Center', 'theme') => 'center',
        )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Width", 'theme'),
         "description" => __("it can be 100% width", 'theme'),
         "param_name" => "width",
         "value" => array(
        __('Fit With Content', 'theme') => '',
        __('Full Width', 'theme') => 'full',
        )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Link", 'theme'),
         "description" => __("the link of the button.", 'theme'),
         "param_name" => "link",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Link target", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "target",
         "value" => array(
        __('Open in same window/tab', 'theme') => '',
        __('Open in new window/tab', 'theme') => '_blan',
        )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Rell", 'theme'),
         "description" => __("the link of the button.", 'theme'),
         "param_name" => "rel",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "font",
         "value" => array(
        __('Default', 'theme') => '',
        __('Arial', 'theme') => 'arial',
        __('Georgia', 'theme') => 'georgia',
        __('Verdana, Geneva', 'theme') => 'verdana',
        __('Trebuchet', 'theme') => 'trebuchet',
        __('Times New Roman', 'theme') => 'times',
        __('Tahoma, Geneva', 'theme') => 'tahoma',
        __('Palatino', 'theme') => 'palatino',
        __('Helvetica', 'theme') => 'helvetica',
        __('Play', 'theme') => 'play',
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font Style", 'theme'),
         "description" => __("normal or italic", 'theme'),
         "param_name" => "font_style",
         "value" => array(
        __('Normal', 'theme') => '',
        __('Italic', 'theme') => 'italic',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font Weight", 'theme'),
         "description" => __("Normal or Bold", 'theme'),
         "param_name" => "font_weight",
         "value" => array(
        __('Normal', 'theme') => '',
        __('Bold', 'theme') => 'bold',        
      )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Radius", 'theme'),
         "description" => __("insert a radius number eg. 10", 'theme'),
         "param_name" => "radius",
         "value" => "",
      ),
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Outer Border", 'theme'),
         "description" => __("its make the button look awesome", 'theme'),
         "param_name" => "outer_border",
         "value" => array(__("Yes/No", "theme") => ''),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Color", 'framework'),
         "param_name" => "outer_border_color",
         "required" => array('outer_border', '', '=='),
      ),
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Icon", 'theme'),
         "description" => __("Tons of icons fit with any button", 'theme'),
         "param_name" => "icon",
         "value" => array(__("Yes/No", "theme") => ''),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Color", 'framework'),
         "param_name" => "icon_color",
         "required" => array('icon', '', '=='),
      ),
    )
));
/** Callout  **/
mse_map( array(
    "name" => __("Callout", "framework"),
    "base" => "callout",
    "category" => __('Goodnews'),
    "icon" => 'fa-bullhorn',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "upload",
         "class" => "",
         "heading" => __("Style", 'theme'),
         "description" => __("insert button text ex: Click Here", 'theme'),
         "param_name" => "bgimg",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Color", 'framework'),
         "param_name" => "bg",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Text Color", 'framework'),
         "param_name" => "color",
      ), 
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Color", 'framework'),
         "param_name" => "border",
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Radius", 'theme'),
         "description" => __("insert a radius number eg. 10", 'theme'),
         "param_name" => "radius",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "font",
         "value" => array(
        __('Default', 'theme') => '',
        __('Arial', 'theme') => 'arial',
        __('Georgia', 'theme') => 'georgia',
        __('Verdana, Geneva', 'theme') => 'verdana',
        __('Trebuchet', 'theme') => 'trebuchet',
        __('Times New Roman', 'theme') => 'times',
        __('Tahoma, Geneva', 'theme') => 'tahoma',
        __('Palatino', 'theme') => 'palatino',
        __('Helvetica', 'theme') => 'helvetica',
        __('Play', 'theme') => 'play',
      )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Font Size", 'theme'),
         "description" => __("insert a font size as a number eg. 14", 'theme'),
         "param_name" => "radius",
         "value" => "",
      ),
      array(
         "type" => "textarea",
         "class" => "",
         "heading" => __("Content", 'theme'),
         "description" => __("Arbitrary text or HTML, shortcodes", 'theme'),
         "param_name" => "content",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Button Position", 'theme'),
         "description" => __("Button Position", 'theme'),
         "param_name" => "bt_pos",
         "value" => array(
        __('Right', 'theme') => '',
        __('Bottom left', 'theme') => 'bottomLeft',
        __('Bottom Right', 'theme') => 'bottomRight',
        __('Bottom center', 'theme') => 'bottomCenter',
      )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Content", 'theme'),
         "description" => __("insert button text ex: Click Here", 'theme'),
         "param_name" => "bt_content",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Color", 'theme'),
         "description" => __("Select one or make your own", 'theme'),
         "param_name" => "bt_color",
         "value" => array(
        __('Default', 'theme') => '',
        __('Yellow', 'theme') => 'yellow',
        __('Orange', 'theme') => 'orange',
        __('Orange2', 'theme') => 'orange2',
        __('Red', 'theme') => 'red',
        __('Brown', 'theme') => 'brown',
        __('Pink', 'theme') => 'pink',
        __('Purple', 'theme') => 'purple',
        __('Dark Green', 'theme') => 'green2',
        __('Green', 'theme') => 'green',
        __('Blue', 'theme') => 'blue',
        __('Dark Blue', 'theme') => 'blue2',
        __('Dark Gray', 'theme') => 'gray2',
        __('Gray', 'theme') => 'gray',
        __('Custom', 'theme') => 'custom',
        )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Size", 'theme'),
         "description" => __("select from medium or big", 'theme'),
         "param_name" => "bt_size",
         "value" => array(
        __('Medium', 'theme') => '',
        __('Big', 'theme') => 'big',
        __('Bigger', 'theme') => 'bigger',
        )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Link", 'theme'),
         "description" => __("the link of the button.", 'theme'),
         "param_name" => "bt_link",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Link Target", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "bt_target",
         "value" => array(
        __('Open in same window/tab', 'theme') => '',
        __('Open in new window/tab', 'theme') => '_blan',
        )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "bt_font",
         "value" => array(
        __('Default', 'theme') => '',
        __('Arial', 'theme') => 'arial',
        __('Georgia', 'theme') => 'georgia',
        __('Verdana, Geneva', 'theme') => 'verdana',
        __('Trebuchet', 'theme') => 'trebuchet',
        __('Times New Roman', 'theme') => 'times',
        __('Tahoma, Geneva', 'theme') => 'tahoma',
        __('Palatino', 'theme') => 'palatino',
        __('Helvetica', 'theme') => 'helvetica',
        __('Play', 'theme') => 'play',
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font Style", 'theme'),
         "description" => __("normal or italic", 'theme'),
         "param_name" => "bt_font_style",
         "value" => array(
        __('Normal', 'theme') => '',
        __('Italic', 'theme') => 'italic',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Font Weight", 'theme'),
         "description" => __("Normal or Bold", 'theme'),
         "param_name" => "bt_font_weight",
         "value" => array(
        __('Normal', 'theme') => '',
        __('Bold', 'theme') => 'bold',        
      )
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Radius", 'theme'),
         "description" => __("insert a radius number eg. 10", 'theme'),
         "param_name" => "bt_radius",
         "value" => "",
      ),
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Outer Border", 'theme'),
         "description" => __("its make the button look awesome", 'theme'),
         "param_name" => "bt_outer_border",
         "value" => array(__("Yes/No", "theme") => ''),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Color", 'framework'),
         "param_name" => "bt_outer_border_color",
         "required" => array('bt_outer_border', '', '=='),
      ),
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Icon", 'theme'),
         "description" => __("Tons of icons fit with any button", 'theme'),
         "param_name" => "bt_icon",
         "value" => array(__("Yes/No", "theme") => ''),  
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Color", 'framework'),
         "param_name" => "bt_icon_color",
         "required" => array('bt_icon', '', '=='),
      ),     
    )
));

/** Graph **/
mse_map( array(
    "name" => __("Graph", "framework"),
    "base" => "graphs",
    "category" => __('Goodnews'),
    "icon" => 'icon-mom_review',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Height", 'theme'),
         "description" => __("insert bar height default is 25", 'theme'),
         "param_name" => "height",
         "value" => "",
      ),
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Enable Strips", 'theme'),
         "description" => __("make it striped", 'theme'),
         "param_name" => "strips",
         "value" => "",
      ),
      array(
         "type" => "textarea",
         "class" => "",
         "heading" => __("Content", 'theme'),
         "description" => __("Add Graph", 'theme'),
         "param_name" => "content",
         "value" => "",
      ),
    )
));

/** Icon **/
mse_map( array(
    "name" => __("Icon", "framework"),
    "base" => "icon",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Align", 'theme'),
         "description" => __("Icon alignment", 'theme'),
         "param_name" => "align",
         "value" => array(
        __('Left', 'theme') => '',
        __('Right', 'theme') => 'right',        
        __('Center', 'theme') => 'center',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Size", 'theme'),
         "description" => __("Select Icon Size. note custom size not work for Image Icons", 'theme'),
         "param_name" => "size",
         "value" => array(
        __('16px', 'theme') => '16',
        __('24px', 'theme') => '24',
        __('32px', 'theme') => '32',
        __('48px', 'theme') => '48',        
        __('Custom Size', 'theme') => 'custom',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon background", 'theme'),
         "description" => __("select icon background type circle, square", 'theme'),
         "param_name" => "icon_bg",
         "value" => array(
        __('None', 'theme') => '',
        __('Square', 'theme') => 'square',
        __('Circle', 'theme') => 'circle',     
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background color", 'framework'),
         "param_name" => "icon_bg_color",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Hover", 'framework'),
         "param_name" => "icon_bg_hover",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border color", 'framework'),
         "param_name" => "icon_bd_color",
         "required" => array('icon_bg', '', '!='),
      ), 
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Hover", 'framework'),
         "param_name" => "icon_bd_hover",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Border Width", 'framework'),
         "param_name" => "icon_bd_width",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Square Radius", 'framework'),
         "param_name" => "square_bg_radius",
         "dependency" => array('element' => "icon_bg", 'value' => array('square')),
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Hover Animation", 'theme'),
         "description" => __("Choes Hover Animation", 'theme'),
         "param_name" => "hover_animation",
         "value" => array(
        __('Border Increase', 'theme') => 'border_increase',
        __('Border Decrease', 'theme') => 'border_decrease',
        __('Icon Move', 'theme') => 'icon_move',     
        __('None', 'theme') => 'none',     
      ),
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon Type", 'theme'),
         "description" => __("vector or images or upload your own icon", 'theme'),
         "param_name" => "type",
         "value" => array(
        __('Vector Icon', 'theme') => 'vector',
        __('Custom Icon', 'theme') => 'custom',   
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon color", 'framework'),
         "param_name" => "icon_color",
         "dependency" => array('element' => "type", 'value' => array('vector')),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Hover", 'framework'),
         "param_name" => "icon_color_hover",
         "dependency" => array('element' => "type", 'value' => array('vector')),
      ),
      array(
         "type" => "mom_icon",
         "class" => "",
         "heading" => __("The Icon", 'theme'),
         "param_name" => "icon",
         "value" => "",
         "dependency" => array('element' => "type", 'value' => array('vector')),
      ),      
      array(
         "type" => "upload",
         "class" => "",
         "heading" => __("Upload Custom Icon", 'theme'),
         "param_name" => "icon",
         "value" => "",
         "dependency" => array('element' => "type", 'value' => array('custom')),
      ),   
    )
));

/** Icon Box **/
mse_map( array(
    "name" => __("Icon Box", "framework"),
    "base" => "iconbox",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("title", 'theme'),
         "description" => __("box title", 'theme'),
         "param_name" => "title",
         "value" => "",       
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Title Align", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "title_align",
         "value" => array(
        __('Left', 'theme') => 'left',
        __('Center', 'theme') => 'center',        
        __('right', 'theme') => 'right',        
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Title Color", 'framework'),
         "param_name" => "title_color",
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Title Link", 'framework'),
         "param_name" => "title_link",
      ),
      array(
         "type" => "textarea",
         "class" => "",
         "heading" => __("Content", 'framework'),
         "description" => __("Arbitrary text or HTML, Shortcodes.", 'theme'),
         "param_name" => "content",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Content Align", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "content_align",
         "value" => array(
        __('Left', 'theme') => 'left',
        __('Center', 'theme') => 'center',        
        __('right', 'theme') => 'right',        
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Content Color", 'framework'),
         "param_name" => "content_color",
      ),
      array(
         "type" => "images",
         "class" => "",
         "heading" => __("Layout", 'framework'),
         "description" => __("plain or boxed", 'theme'),
         "param_name" => "layout",
         'options' => array(
            '' => array('name' => __('Plain','theme'), 'src' => $images.'/plainbox.png'),
            'boxed' => array('name' => __('Plain','theme'), 'src' => $images.'/boxed.png'),
          )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background color", 'framework'),
         "param_name" => "bg",
         "dependency" => array('element' => "layout", 'value' => array('boxed')),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border color", 'framework'),
         "param_name" => "border",
         "dependency" => array('element' => "layout", 'value' => array('boxed')),
      ),
      array(
         "type" => "images",
         "class" => "",
         "heading" => __("Icon Alignment", 'framework'),
         "description" => __("select icon position", 'theme'),
         "param_name" => "align",
         'options' => array(
            '' => array('name' => __('Left','theme'), 'src' => $images.'/iconleft.png'),
            'center' => array('name' => __('Center','theme'), 'src' => $images.'/iconcenter.png'),
            'right' => array('name' => __('Right','theme'), 'src' => $images.'/iconright.png'),
            'middle_left' => array('name' => __('Middle Left','theme'), 'src' => $images.'/iconmleft.png'),
            'middle_right' => array('name' => __('Middle Right','theme'), 'src' => $images.'/iconmright.png'),
          )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon Align to", 'theme'),
         "description" => __("box or title", 'theme'),
         "param_name" => "icon_align_to",
         "value" => array(
        __('Box', 'theme') => 'box',
        __('Title', 'theme') => 'title',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Size", 'theme'),
         "description" => __("Select Icon Size. note custom size not work for Image Icons", 'theme'),
         "param_name" => "icon-size",
         "value" => array(
        __('16px', 'theme') => '16',
        __('24px', 'theme') => '24',
        __('32px', 'theme') => '32',
        __('48px', 'theme') => '48',        
        __('Custom Size', 'theme') => 'custom',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon background", 'theme'),
         "description" => __("select icon background type circle, square", 'theme'),
         "param_name" => "icon_bg",
         "value" => array(
        __('None', 'theme') => '',
        __('Square', 'theme') => 'square',
        __('Circle', 'theme') => 'circle',       
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Color", 'theme'),
         "param_name" => "icon_bg_color",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Hover", 'theme'),
         "param_name" => "icon_bg_hover",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Color", 'theme'),
         "param_name" => "icon_bd_color",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Hover", 'theme'),
         "param_name" => "icon_bd_hover",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Border Width", 'theme'),
         "param_name" => "icon_bd_width",
         "value" => "",
         "required" => array('icon_bg', '', '!='),     
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Square Radius", 'theme'),
         "param_name" => "square_bg_radius",
         "value" => "",
         "dependency" => array('element' => "icon_bg", 'value' => array('square')),     
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Hover Animation", 'theme'),
         "description" => __("", 'theme'),
         "param_name" => "hover_animation",
         "value" => array(
        __('Border Increase', 'theme') => 'border_increase',
        __('border_decrease', 'theme') => 'border_decrease',
        __('Icon Move', 'theme') => 'icon_move',       
        __('None', 'theme') => 'none',       
      ),
         "required" => array('icon_bg', '', '!='), 
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Icon Link", 'theme'),
         "description" => __("icon link if needed", 'theme'),
         "param_name" => "icon_link",
         "value" => "",     
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon Animatin", 'theme'),
         "description" => __("tons of animations", 'theme'),
         "param_name" => "icon_animation",
         "options" => $ani,
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon Type", 'theme'),
         "description" => __("vector or upload your own icon", 'theme'),
         "param_name" => "type",
         "value" => array(
        __('Vector Icon', 'theme') => 'vector',
        __('Custom Icon', 'theme') => 'custom',   
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Color", 'theme'),
         "param_name" => "icon_color",
         "value" => "",
          "dependency" => array('element' => "type", 'value' => array('vector')),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Hover", 'theme'),
         "param_name" => "icon_color_hover",
         "value" => "",
          "dependency" => array('element' => "type", 'value' => array('vector')),
      ),
      array(
         "type" => "mom_icon",
         "class" => "",
         "heading" => __("The Icon", 'theme'),
         "param_name" => "icon",
         "value" => "",
         "dependency" => array('element' => "type", 'value' => array('vector')),
      ),      
      array(
         "type" => "upload",
         "class" => "",
         "heading" => __("Upload Custom Icon", 'theme'),
         "param_name" => "icon",
         "value" => "",
         "dependency" => array('element' => "type", 'value' => array('custom')),
      ),

    )
));

/** Images Grid **/
mse_map( array(
    "name" => __("Images Grid", "framework"),
    "base" => "images",
    "category" => __('Goodnews'),
    "icon" => 'fa-th',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Type", 'theme'),
         "description" => __("grid or caruosel", 'theme'),
         "param_name" => "type",
         "value" => array(
        __('Grid', 'theme') => '',
        __('Carousel', 'theme') => 'carousel',   
      )
      ),
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Auto Slide", 'theme'),
         "param_name" => "auto_slide",
         "dependency" => array('element' => "type", 'value' => array('carousel')),
      ),
      array(
         "type" => "txte",
         "class" => "",
         "heading" => __("Auto Slide Duration by ms", 'theme'),
         "param_name" => "auto_duration",
         "value" => "",
         "dependency" => array('element' => "type", 'value' => array('carousel')),
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Columns", 'theme'),
         "description" => __("grid or caruosel", 'theme'),
         "param_name" => "cols",
         "value" => array(
        __('three', 'theme') => 'Three Columns',
        __('four', 'theme') => 'Four Columns',   
        __('five', 'theme') => 'Five Columns',   
        __('six', 'theme') => 'Six Columns',   
      )
      ),
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __("Enable lightbox", 'theme'),
         "description" => __("if you enable this the image link must be the big image url if you leave link empty the lightbox open the same image", 'theme'),
         "param_name" => "lightbox",
         "value" => "",
      ),
    )
));

/** lightbox **/
mse_map( array(
    "name" => __("lightbox", "framework"),
    "base" => "lightbox",
    "category" => __('Goodnews'),
    "icon" => 'fa-codepen',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "upload",
         "class" => "",
         "heading" => __("Lightbox Thumbnail", 'theme'),
         "param_name" => "thumb",
         "value" => "",
      ),

      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Type", 'theme'),
         "description" => __("image or video", 'theme'),
         "param_name" => "type",
         "value" => array(
        __('Image', 'theme') => '',
        __('Video', 'theme') => 'video',     
      )
      ),
            array(
         "type" => "text",
         "class" => "",
         "heading" => __("Link", 'theme'),
         "description" => __("it can be image link or video link (youtube / vimeo only), if leave empty it will be the thumbnail image link.", 'theme'),
         "param_name" => "link",
         "value" => "",
      ),

    )
));

/** Lists **/
mse_map( array(
    "name" => __("Lists", "framework"),
    "base" => "list",
    "category" => __('Goodnews'),
    "icon" => 'fa-list',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "textarea",
         "class" => "",
         "heading" => __("Content", 'theme'),
         "description" => __("List items", 'theme'),
         "param_name" => "content",
         "value" => "",
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Space above it", 'theme'),
         "param_name" => "margin_top",
         "value" => "",
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Space under it", 'theme'),
         "param_name" => "margin_bottom",
         "value" => "",
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon Background", 'theme'),
         "description" => __("scircle and square available", 'theme'),
         "param_name" => "icon_bg",
         "value" => array(
        __('None', 'theme') => '',
        __('Square', 'theme') => 'square',
        __('Circle', 'theme') => 'circle',     
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Color", 'theme'),
         "param_name" => "icon_bg_color",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Hover", 'theme'),
         "param_name" => "icon_bg_hover",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Square Radius", 'theme'),
         "param_name" => "square_bg_radius",
         "value" => "",
         "dependency" => array('element' => "icon_bg", 'value' => array('square')),
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Icon Size", 'theme'),
         "description" => __("default icon size is 16 some icons maybe looking big or small so you can change icon size from here", 'theme'),
         "param_name" => "icon_color_hover",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Color", 'theme'),
         "param_name" => "icon_color",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Hover", 'theme'),
         "param_name" => "icon_color_hover",
         "value" => "",
      ),
      array(
         "type" => "mom_icon",
         "class" => "",
         "heading" => __("Momizat Icons", 'theme'),
         "param_name" => "icon",
         "value" => "",
      ), 
    )
));

/** Social Icons **/
mse_map( array(
    "name" => __("Social Icons", "framework"),
    "base" => "social",
    "category" => __('Goodnews'),
    "icon" => 'fa-code-fork',
    "description" => __("", 'theme'),
    "content_element" => true,
    "js_view" => 'VcColumnView',
    
    
    "params" => array(
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Align", 'theme'),
         "description" => __("Icon alignment", 'theme'),
         "param_name" => "align",
         "value" => array(
        __('Left', 'theme') => '',
        __('Right', 'theme') => 'right',        
        __('Center', 'theme') => 'center',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Size", 'theme'),
         "description" => __("set Icon Size", 'theme'),
         "param_name" => "size",
         "value" => array(
        __('16px', 'theme') => '16',
        __('24px', 'theme') => '24',
        __('32px', 'theme') => '32',
        __('48px', 'theme') => '48',        
        __('Custom Size', 'theme') => 'custom',        
      )
      ),
      array(
         "type" => "dropdown",
         "class" => "",
         "heading" => __("Icon background", 'theme'),
         "description" => __("select icon background type circle, square", 'theme'),
         "param_name" => "icon_bg",
         "value" => array(
        __('None', 'theme') => '',
        __('Square', 'theme') => 'square',
        __('Circle', 'theme') => 'circle',     
      )
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background color", 'framework'),
         "param_name" => "icon_bg_color",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Background Hover", 'framework'),
         "param_name" => "icon_bg_hover",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border color", 'framework'),
         "param_name" => "icon_bd_color",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ), 
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Border Hover", 'framework'),
         "param_name" => "icon_bd_hover",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Border Width", 'framework'),
         "param_name" => "icon_bd_width",
         "value" => "",
         "required" => array('icon_bg', '', '!='),
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Square Radius", 'framework'),
         "param_name" => "square_bg_radius",
         "value" => "",
         "dependency" => array('element' => "icon_bg", 'value' => array('square')),
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Icon Link", 'framework'),
         "description" => __("the social link", 'theme'),
         "param_name" => "link",
         "value" => "",
      ),
      array(
         "type" => "text",
         "class" => "",
         "heading" => __("Icon Tooltip", 'framework'),
         "description" => __("social icon name just see it on hover state", 'theme'),
         "param_name" => "tooltip",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon color", 'framework'),
         "param_name" => "icon_color",
         "value" => "",
      ),
      array(
         "type" => "colorpicker",
         "class" => "",
         "heading" => __("Icon Hover", 'framework'),
         "param_name" => "icon_color_hover",
         "value" => "",
      ),
      array(
         "type" => "mom_icon",
         "class" => "",
         "heading" => __("Momizat Icons", 'framework'),
         "param_name" => "icon",
         "value" => "",
      ),
    )
));

} // if shortcode editor installed
?>