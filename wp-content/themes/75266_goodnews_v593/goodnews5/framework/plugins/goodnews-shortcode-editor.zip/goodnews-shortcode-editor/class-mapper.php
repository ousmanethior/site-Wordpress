<?php 
/*
	shortcodes mapper

 */

if (! class_exists('MOM_mse_MAP')) 
{

	class MOM_mse_MAP {
		protected static $instance = null;

		/**
		 * add shrotcode 
		 *
		 * @since	 1.0.0
		 */
		
		public static function add ( $shortcode = array() ) {
				if (! isset($shortcode['base'])) {
					return;	
				}
				if (! isset($shortcode['name'])) {
					return;	
				}
				
				$shortcodes = get_option( 'mom_mse_shortcodes', array() );

				$shortcodes[$shortcode['base']] = $shortcode ;
				
				update_option('mom_mse_shortcodes', $shortcodes);

		}

		/**
		 * Return an instance of this class.
		 *
		 * @since	 1.0.0
		 *
		 * @return	object	A single instance of this class.
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;

		}


	}	
}

function mse_map($shortcode) {
	MOM_mse_MAP::add($shortcode);
}