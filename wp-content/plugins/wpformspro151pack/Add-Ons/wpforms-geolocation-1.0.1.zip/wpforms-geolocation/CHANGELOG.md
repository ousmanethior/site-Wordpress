# Change Log
All notable changes to this project will be documented in this file, formatted via [this recommendation](http://keepachangelog.com/).

## [1.0.1] - 2016-08-04
### Fixed
- Bug preventing IP addresses from processing

## [1.0.0] - 2016-08-03
### Added
- Initial release